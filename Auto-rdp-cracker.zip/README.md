# auto-rdp-cracker
A python3 full automatic rdp cracker based on hydra THC

## HOW TO COMPILE
**At first you need to install hydra THC on your terminal** 
```bash
sudo add-apt-repository ppa:pi-rho/security

sudo apt-get update

sudo apt-get install hydra
```
**Then you need to install python3 required library**
```bash
pip3 install netaddr
```
**Finally you can run script**
```
python3 auto.py
```
Notice that you can use own passwords and usernames,
just with replacing passwords.txt and usernames.txt

**Hope Enjoy!**
