# crackrdp
#### Bash script to crack rdp with THC-Hydra
#### Can be installed in Debian, Ubuntu, Kali and CentOS

## installation
#### sh install.sh
## usage
#### cd rdpcrack && ./crackrdp 24.100.0.0-24.100.255.255
## credentials
#### They are stored in directory rdpcrack/ user and pass files
## Active logins:

#### cat hydra.log | grep login:

## Warning: scanning a lots of IPs will freeze your shell out of memory, so dont scan too many subnets.
